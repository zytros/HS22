# Homework 03

## Topics

* Diffusion and Finite Differences
* OpenMP
* PCA and Ddimensionality Rreduction


## Tutorials

For Question 1, see the associated tutorial:

```
tutorials/tutorial05_Diffusion
```
